If you want to download the map png files. Checkout `script-download-map.js`.

Then go to `app.js` change this `let useLocalResource = false` to `let useLocalResource = true`.
